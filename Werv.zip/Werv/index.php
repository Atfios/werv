<?php
session_start();

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require_once "db.php";

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT username, profile_pic FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username, $profilePic);
$stmt->fetch();
$stmt->close();

// Posts sample (Replace with DB fetch later)
$posts = [
    ["author" => "Adam 3aatfi", "content" => "the best sunset Ever", "image" => "img/sunset.jpeg"],
    ["author" => "Adam 3aatfi", "content" => "the best sunset Ever", "image" => "img/sunset.jpeg"],
    ["author" => "Adam 3aatfi", "content" => "the best sunset Ever", "image" => "img/sunset.jpeg"]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Werv</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/index_search.css">
</head>
<body>

<!-- Search Sidebar (خارج container) -->
<div class="search-sidebar" id="searchSidebar">
    <div class="search-header">
        <input type="text" placeholder="Search users..." id="searchInput">
        <i class="fa-solid fa-xmark close-search" onclick="toggleSearchSidebar()"></i>
    </div>
    <div class="search-results" id="searchResults"></div>
</div>

<div class="container">
    <header>
        <div class="logo"><h1>Werv</h1></div>
    </header>

    <div class="pages">
        <div class="icon"><i class="fa-solid fa-house"></i><p>Home</p></div>
        <div class="icon"><i class="fa-regular fa-paper-plane"></i><p>Messages</p></div>
        <div class="icon"><i class="fa-regular fa-comments"></i><p>Open Chat</p></div>
        <div class="icon" id="searchButton"><i class="fa fa-search"></i><p>Search</p></div>
        <div class="icon"><i class="fa-regular fa-bell"></i><p>Notification</p></div>
        <div class="icon"><i class="fa-regular fa-plus"></i><p>Add Post</p></div>
        <div class="icon pdp_image">
            <?php if (!empty($profilePic) && file_exists("uploads/" . $profilePic)): ?>
                <img src="uploads/<?php echo htmlspecialchars($profilePic); ?>" alt="Profile">
            <?php else: ?>
                <img src="img/default.png" alt="Default Profile">
            <?php endif; ?>
            <p><?php echo htmlspecialchars($username); ?></p>
        </div>
    </div>

    <div class="bars" onclick="window.location.href='logout.php'">
  <i class="fa-solid fa-right-from-bracket"></i>
  <p>Logout</p>
</div>


</div>

<div class="stories-wrapper">
    <button class="scroll-btn left" onclick="scrollStories(-1)"><i class="fa-solid fa-arrow-left"></i></button>
    <div class="stories-container" id="storySlider">
        <div class="story add-story">
            <div class="story-img"><span class="plus-icon">+</span></div>
            <p>Your Story</p>
        </div>
        <?php $friends = ['Adam', 'Omar', 'Rayan', 'Walaa', 'Chaimae', 'Ni3ma', 'Maram']; ?>
        <?php foreach ($friends as $friend): ?>
            <div class="story">
                <img src="img/profile.png" alt="<?php echo $friend; ?>" class="story-img" />
                <p><?php echo htmlspecialchars($friend); ?></p>
            </div>
        <?php endforeach; ?>
    </div>
    <button class="scroll-btn right" onclick="scrollStories(1)"><i class="fa-solid fa-arrow-right"></i></button>
</div>

<div class="feed-container">
    <?php foreach ($posts as $post): ?>
        <div class="post-card">
            <div class="post-header">
                <img src="img/profile.png" alt="User" class="avatar">
                <div class="post-user-info">
                    <h4><?php echo htmlspecialchars($post['author']); ?></h4>
                    <span>now</span>
                </div>
                <i class="fa-solid fa-ellipsis"></i>
            </div>
            <div class="post-content">
                <p><?php echo htmlspecialchars($post['content']); ?></p>
                <img src="<?php echo htmlspecialchars($post['image']); ?>" alt="Post Image" class="post-image">
            </div>
            <div class="post-actions">
                <div><i class="fa-regular fa-heart"></i> <span>132</span></div>
                <div><i class="fa-regular fa-comment"></i> <span>27</span></div>
                <div><i class="fa-regular fa-share-from-square"></i></div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="comunity">
    <div class="comunity-card">
        <img src="img/rocket.png" alt="User">
        <div class="comunity-info">
            <h4>Create your comunity</h4>
            <button class="btn">Create</button>
        </div>
        <a href="#">Search for one</a>
    </div>
</div>








      <script src="js/script.js"></script>
      <script src="js/searchslid.js"></script>
      <script>
    const menuBtn = document.getElementById('menu-button');
    const plusMenu = document.getElementById('plus-menu');

    menuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      plusMenu.classList.toggle('visible');
    });

    document.addEventListener('click', (e) => {
      if (!plusMenu.contains(e.target) && !menuBtn.contains(e.target)) {
        plusMenu.classList.remove('visible');
      }
    });
  </script>
</body>
</html>