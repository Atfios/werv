<?php
session_start();

require_once "db.php";
$conn->set_charset("utf8mb4");
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Check if user is already logged in via session
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

// Check "remember me pro max" cookie
if (isset($_COOKIE['remember_token'])) {
    $token = $_COOKIE['remember_token'];
    $stmt = $conn->prepare("SELECT id FROM users WHERE remember_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows === 1) {
        $stmt->bind_result($userId);
        $stmt->fetch();
        $_SESSION['user_id'] = $userId;
        header("Location: index.php");
        exit;
    }
    $stmt->close();
}
?>


<?php
$conn->set_charset("utf8mb4");
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

function sanitize($data) {
    return trim($data);
}

$errors = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $fullname = sanitize($_POST['fullname'] ?? '');
    $username = sanitize($_POST['username'] ?? '');
    $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $phone = sanitize($_POST['phone'] ?? '');
    $dob = $_POST['dob'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';
    $gender = sanitize($_POST['gender'] ?? '');

    if (!$fullname || !$username || !$email || !$phone || !$dob || !$password || !$confirmPassword || !$gender) {
        $errors[] = "All fields are required.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (!preg_match("/^[0-9]{10}$/", $phone)) {
        $errors[] = "Phone number must be exactly 10 digits.";
    }

    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match.";
    }

    if (strtotime($dob) === false || strtotime($dob) > time()) {
        $errors[] = "Invalid date of birth.";
    }

    $check = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $check->bind_param("ss", $username, $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $errors[] = "Username or email already exists.";
    }
    $check->close();

    $profilePicName = null;
    if (isset($_FILES['profilePic']) && $_FILES['profilePic']['error'] === 0) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 2 * 1024 * 1024;
        $type = mime_content_type($_FILES['profilePic']['tmp_name']);
        $size = $_FILES['profilePic']['size'];

        if (!in_array($type, $allowedTypes)) {
            $errors[] = "Only JPG, PNG, and GIF files are allowed.";
        } elseif ($size > $maxSize) {
            $errors[] = "Image must be less than 2MB.";
        } else {
            $uploadDir = "uploads/";
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            $uniqueName = uniqid() . "_" . basename($_FILES['profilePic']['name']);
            $targetPath = $uploadDir . $uniqueName;

            if (move_uploaded_file($_FILES['profilePic']['tmp_name'], $targetPath)) {
                $profilePicName = $uniqueName;
            } else {
                $errors[] = "Failed to upload profile picture.";
            }
        }
    }

    if (empty($errors)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $token = bin2hex(random_bytes(32)); // ممكن تحيد هاد السطر إلا مبقاش ضروري

        $stmt = $conn->prepare("INSERT INTO users (fullname, username, email, phone, dob, password, gender, profile_pic) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $fullname, $username, $email, $phone, $dob, $hashedPassword, $gender, $profilePicName);

        if ($stmt->execute()) {
            header("Location: login.php?success=1");
        } else {
            $errors[] = "Registration failed: " . $stmt->error;
        }

        $stmt->close();
    }
}
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Register - Werv</title>
  <link rel="stylesheet" href="css/register.css" />
</head>
<body>
  <div class="wrapper">
    <?php
    // عرض الأخطاء هنا قبل الفورم
    if (!empty($errors)) {
        echo "<div class='error-box'>";
        foreach ($errors as $err) {
            echo "<p>$err</p>";
        }
        echo "</div>";
    }
  ?>
    <form class="register-form" action="register.php" method="POST" enctype="multipart/form-data">
      <div class="form-section">
        <h2>Personal Information</h2>
        <div class="input-group">
          <label for="fullname">Full Name</label>
          <input type="text" id="fullname" name="fullname" required />
        </div>
        <div class="input-group">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" required />
        </div>
        <div class="input-group">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" required />
        </div>
        <div class="input-group">
          <label for="phone">Phone</label>
          <input type="tel" id="phone" name="phone" required />
        </div>
        <div class="input-group">
          <label for="dob">Date of Birth</label>
          <input type="date" id="dob" name="dob" required />
        </div>
      </div>

      <div class="form-section">
        <h2>Account Details</h2>
        <div class="input-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" required />
        </div>
        <div class="input-group">
          <label for="confirmPassword">Confirm Password</label>
          <input type="password" id="confirmPassword" name="confirmPassword" required />
        </div>
        <div class="input-group">
          <label for="gender">Gender</label>
          <select id="gender" name="gender" required>
            <option value="">Select gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">potato</option>
          </select>
        </div>
        <div class="input-group">
          <label for="profilePic">Profile Picture</label>
          <input type="file" id="profilePic" name="profilePic" accept="image/*" />
        </div>
        <div class="input-group">
          <button type="submit" class="btn">Register</button>
          <p>Already have an account? <a href="login.php">Login</a></p>
        </div>
      </div>
    </form>
  </div>

  <script>
  setTimeout(() => {
    const box = document.querySelector('.error-box');
    if (box) {
      box.remove();
    }
  }, 4000); // 3s delay + 1s animation
</script>

<script src="js/isvalid.js"></script>

</body>
</html>