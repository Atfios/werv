// profile.js

document.addEventListener("DOMContentLoaded", () => {
  // نجيب الزر ديال 3 نقاط
  const optionsBtn = document.querySelector(".options-btn");

  // نخلق عنصر القائمة (dropdown menu)
  const dropdown = document.createElement("div");
  dropdown.classList.add("options-dropdown");
  dropdown.style.position = "absolute";
  dropdown.style.background = "#fff";
  dropdown.style.border = "1px solid #ccc";
  dropdown.style.boxShadow = "0 2px 5px rgba(0,0,0,0.2)";
  dropdown.style.padding = "8px 0";
  dropdown.style.borderRadius = "5px";
  dropdown.style.display = "none";
  dropdown.style.minWidth = "120px";
  dropdown.style.zIndex = "1000";

  // نزيد العناصر ديال القائمة
  const items = [
    { text: "Repost", action: () => alert("Repost clicked") },
    { text: "Block", action: () => alert("Block clicked") },
    { text: "Report", action: () => alert("Report clicked") },
  ];

  items.forEach(({ text, action }) => {
    const item = document.createElement("div");
    item.textContent = text;
    item.style.padding = "8px 12px";
    item.style.cursor = "pointer";
    item.style.fontSize = "14px";
    item.style.color = "#333";

    item.addEventListener("mouseenter", () => {
      item.style.backgroundColor = "#eee";
    });
    item.addEventListener("mouseleave", () => {
      item.style.backgroundColor = "transparent";
    });

    item.addEventListener("click", () => {
      action();
      dropdown.style.display = "none"; // تسد القائمة بعد الضغط
    });

    dropdown.appendChild(item);
  });

  // نضيف القائمة لجسم الصفحة (لكن مخبية)
  document.body.appendChild(dropdown);

  // وظيفة باش نحط القائمة فبلاصتها تحت الزر
  function positionDropdown() {
    const rect = optionsBtn.getBoundingClientRect();
    dropdown.style.top = rect.bottom + window.scrollY + "px";
    dropdown.style.left = rect.left + window.scrollX + "px";
  }

  // لما نضغط على الزر ديال 3 نقاط
  optionsBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    if (dropdown.style.display === "none") {
      positionDropdown();
      dropdown.style.display = "block";
    } else {
      dropdown.style.display = "none";
    }
  });

  // تسد القائمة إلا ضغطنا فين ما كان خارجها
  document.addEventListener("click", () => {
    dropdown.style.display = "none";
  });
});


