function toggleSearchSidebar() {
    const sidebar = document.getElementById('searchSidebar');
    sidebar.classList.toggle('open');
}

document.addEventListener('DOMContentLoaded', () => {
    const searchBtn = document.getElementById('searchButton');
    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');

    if (searchBtn) {
        searchBtn.addEventListener('click', toggleSearchSidebar);
    }

    if (searchInput && searchResults) {
        searchInput.addEventListener('input', function () {
            const query = this.value.trim();

            if (query.length === 0) {
                searchResults.innerHTML = '';
                return;
            }

            fetch('search_users.php?q=' + encodeURIComponent(query))
                .then(res => res.text())
                .then(data => {
                    searchResults.innerHTML = data;
                })
                .catch(() => {
                    searchResults.innerHTML = '<p>Error</p>';
                });
        });
    }
});
