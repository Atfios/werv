document.addEventListener("DOMContentLoaded", function () {
    const btn = document.getElementById("followBtn");
    if (!btn) return;

    btn.addEventListener("click", function () {
        const following = btn.getAttribute("data-following");
        const followedId = btn.getAttribute("data-followed-id");

        fetch("follow_action.php", {
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            body: `followed_id=${followedId}&action=${following === "1" ? "unfollow" : "follow"}`
        })
        .then((res) => res.text())
        .then((data) => {
            if (data === "success") {
                const isNowFollowing = following === "0";
                btn.setAttribute("data-following", isNowFollowing ? "1" : "0");
                btn.textContent = isNowFollowing ? "Unfollow" : "Follow";
                location.reload();
            }
        })
        .catch((err) => console.error("Error:", err));
    });
});
