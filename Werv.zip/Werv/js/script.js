
function scrollStories(direction) {
    const container = document.getElementById('storySlider');
    const scrollAmount = 150;
    container.scrollBy({
        left: direction * scrollAmount,
        behavior: 'smooth'
    });

    // Delay check slightly to allow scroll to finish
    setTimeout(checkArrowVisibility, 300);
}

// Check if we're at scroll start/end
function checkArrowVisibility() {
    const container = document.getElementById('storySlider');
    const leftArrow = document.querySelector('.scroll-btn.left');
    const rightArrow = document.querySelector('.scroll-btn.right');

    // Check if at start
    if (container.scrollLeft <= 5) {
        leftArrow.style.display = 'none';
    } else {
        leftArrow.style.display = 'block';
    }

    // Check if at end
    if (container.scrollWidth - container.clientWidth - container.scrollLeft <= 5) {
        rightArrow.style.display = 'none';
    } else {
        rightArrow.style.display = 'block';
    }
}

// Check visibility on load and scroll
window.addEventListener('load', checkArrowVisibility);
document.getElementById('storySlider').addEventListener('scroll', checkArrowVisibility);

