const form = document.querySelector(".register-form");

const rules = {
  fullname: val => val.trim().length > 0,
  username: val => val.trim().length > 0,
  email: val => /^[a-zA-Z0-9._%+-]+@gmail\.com$/.test(val),
  phone: val => /^[0-9]{10}$/.test(val),
  dob: val => {
    const date = new Date(val);
    const now = new Date();
    return val && date instanceof Date && !isNaN(date) && date < now;
  },
  password: val => /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{7,}$/.test(val),
  confirmPassword: (val, allValues) => val === allValues.password,
  gender: val => val !== ""
};

function showError(input, message) {
  let error = input.nextElementSibling;
  if (!error || !error.classList.contains('error-message')) {
    error = document.createElement('div');
    error.classList.add('error-message');
    input.parentNode.insertBefore(error, input.nextSibling);
  }
  error.textContent = message;
  input.classList.add('input-error');
}

function clearError(input) {
  let error = input.nextElementSibling;
  if (error && error.classList.contains('error-message')) {
    error.textContent = '';
  }
  input.classList.remove('input-error');
}

form.querySelectorAll('input, select').forEach(input => {
  input.addEventListener('input', () => {
    const val = input.value;
    const name = input.name;

    let valid;
    if(name === 'confirmPassword') {
      valid = rules.confirmPassword(val, {
        password: form.querySelector('[name="password"]').value
      });
    } else if (rules[name]) {
      valid = rules[name](val);
    } else {
      valid = true;
    }

    if (!valid) {
      let msg = "that field is invalid";
      if (name === 'email') msg = "We accept only Gmail addresses";
      else if (name === 'phone') msg = "We accept only 10-digit phone numbers";
      else if (name === 'password') msg = "Password must be at least 7 characters long and include uppercase, lowercase, number, and symbol";
      else if (name === 'confirmPassword') msg = "Passwords do not match";
      else if (name === 'dob') msg = "Invalid date of birth or future date";
      else if (name === 'gender') msg = "Please select a gender";
      else if (name === 'fullname' || name === 'username') msg = "This field is required";
      showError(input, msg);
    } else {
      clearError(input);
    }
  });
});

// validation فاش كيحاول يبعث الفورم
form.addEventListener('submit', e => {
  let isFormValid = true;
  form.querySelectorAll('input, select').forEach(input => {
    const val = input.value;
    const name = input.name;

    let valid;
    if(name === 'confirmPassword') {
      valid = rules.confirmPassword(val, {
        password: form.querySelector('[name="password"]').value
      });
    } else if (rules[name]) {
      valid = rules[name](val);
    } else {
      valid = true;
    }

    if (!valid) {
      isFormValid = false;
      let msg = "that field is invalid";
      if (name === 'email') msg = "We accept only Gmail addresses";
      else if (name === 'phone') msg = "We accept only 10-digit phone numbers";
      else if (name === 'password') msg = "Password must be at least 7 characters long and include uppercase, lowercase, number, and symbol";
      else if (name === 'confirmPassword') msg = "Passwords do not match";
      else if (name === 'dob') msg = "Invalid date of birth or future date";
      else if (name === 'gender') msg = "Please select a gender";
      else if (name === 'fullname' || name === 'username') msg = "This field is required";
      showError(input, msg);
    } else {
      clearError(input);
    }
  });

  if (!isFormValid) {
    e.preventDefault();
    alert("Please correct the errors before registering.");
  }
});
