<?php
session_start();
$error = "";

// إذا كان المستخدم مسجل دخول، دّيه للصفحة الرئيسية
if (isset($_SESSION['username']) && isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// التحقق من remember_token فالكوكي
if (!isset($_SESSION['username']) && isset($_COOKIE['remember_token'])) {
    require_once "db.php";
    if (!$conn->connect_error) {
        $token = $_COOKIE['remember_token'];
        $stmt = $conn->prepare("SELECT id, username FROM users WHERE remember_token = ?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($user_id, $username);
            $stmt->fetch();
            $_SESSION['username'] = $username;
            $_SESSION['user_id'] = $user_id;
            header("Location: index.php");
            exit();
        }
        $stmt->close();
        $conn->close();
    }
}

// إذا ضغط المستخدم على زر الدخول
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    require_once "db.php";
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($user_id, $hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            // تسجيل الدخول
            $_SESSION['username'] = $username;
            $_SESSION['user_id'] = $user_id;

            // remember me pro max
            if (isset($_POST['remember'])) {
                $token = bin2hex(random_bytes(32));
                setcookie("remember_token", $token, time() + (86400 * 30), "/"); // صالح لشهر

                $update = $conn->prepare("UPDATE users SET remember_token = ? WHERE id = ?");
                $update->bind_param("si", $token, $user_id);
                $update->execute();
                $update->close();
            }

            header("Location: index.php");
            exit();
        } else {
            $error = "Wrong password. Try again.";
        }
    } else {
        $error = "Username not found.";
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Werv - Login</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <?php if (!empty($error)): ?>
        <div class="error-box"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="wrapper">
        <form method="post" action="">
            <h2>Login to your account</h2>

            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required placeholder="Enter your username">
            </div>

            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required placeholder="Enter your password">
            </div>

            <div class="input-group">
                <input type="checkbox" id="remember" name="remember">
                <label for="remember">Remember me</label>
            </div>

            <button class="btn" type="submit">Let's Go</button>

            <p class="login-link">You don't have an account? <a href="register.php">Create one</a></p>
        </form>
    </div>
</body>
</html>
