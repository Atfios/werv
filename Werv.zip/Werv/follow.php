<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Not logged in']);
    exit();
}

if (!isset($_POST['action'], $_POST['user_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request']);
    exit();
}

$follower_id = $_SESSION['user_id'];
$followed_id = intval($_POST['user_id']);
$action = $_POST['action'];

if ($follower_id === $followed_id) {
    http_response_code(400);
    echo json_encode(['error' => 'You cannot follow yourself']);
    exit();
}

if ($action === 'follow') {
    // إضافة فولو
    $stmt = $conn->prepare("INSERT IGNORE INTO follows (follower_id, followed_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $follower_id, $followed_id);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['status' => 'followed']);
} elseif ($action === 'unfollow') {
    // إزالة الفولو
    $stmt = $conn->prepare("DELETE FROM follows WHERE follower_id = ? AND followed_id = ?");
    $stmt->bind_param("ii", $follower_id, $followed_id);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['status' => 'unfollowed']);
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid action']);
}
?>
