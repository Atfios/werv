<?php
session_start();
require_once "db.php";
if (!$conn) {
    die("Database connection failed");
}

if (!isset($_GET['q']) || empty(trim($_GET['q']))) {
    echo "<p>Search for someone</p>";
    exit;
}

$search = trim($_GET['q']);
$searchLike = "%" . $search . "%";
$regexp = str_replace([' ', '_', '.'], '.', $search);

$sql = "SELECT id, username, fullname, profile_pic 
        FROM users 
        WHERE username LIKE ? OR fullname LIKE ? OR username REGEXP ? OR fullname REGEXP ? 
        LIMIT 10";


$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $searchLike, $searchLike, $regexp, $regexp);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<p>no user found</p>";
} else {
    while ($row = $result->fetch_assoc()) {
        $username = htmlspecialchars($row['username']);
        $fullName = htmlspecialchars($row['fullname']);
        $profile = !empty($row['profile_pic']) && file_exists("uploads/" . $row['profile_pic']) 
                ? "uploads/" . $row['profile_pic'] 
                : "img/profile.png";
        echo "
<a href='profile.php?id={$row['id']}' class='search-user'>
    <img src='$profile' alt='User'>
    <span>$fullName (@$username)</span>
</a>";

    }
}

exit;
?>
