<?php
session_start();
require_once "db.php";

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$profile_id = intval($_GET['id']);

// جلب بيانات المستخدم
$sql = "SELECT username, fullname, profile_pic FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $profile_id);
$stmt->execute();
$stmt->bind_result($username, $fullname, $profile_pic);
$stmt->fetch();
$stmt->close();

if (!$username) {
    echo "User not found.";
    exit();
}

// عدد المتابعين
$stmt = $conn->prepare("SELECT COUNT(*) FROM follows WHERE followed_id = ?");
$stmt->bind_param("i", $profile_id);
$stmt->execute();
$stmt->bind_result($followers_count);
$stmt->fetch();
$stmt->close();

// عدد اللي كيتابعهم
$stmt = $conn->prepare("SELECT COUNT(*) FROM follows WHERE follower_id = ?");
$stmt->bind_param("i", $profile_id);
$stmt->execute();
$stmt->bind_result($following_count);
$stmt->fetch();
$stmt->close();

// واش المستخدم متابع هاد الشخص
$is_following = false;
if (isset($_SESSION['user_id'])) {
    $current_user_id = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT 1 FROM follows WHERE follower_id = ? AND followed_id = ?");
    $stmt->bind_param("ii", $current_user_id, $profile_id);
    $stmt->execute();
    $stmt->store_result();
    $is_following = $stmt->num_rows > 0;
    $stmt->close();
}

// منشورات مؤقتة
$posts = [
    "img/sunset.jpeg",
    "img/sunset.jpeg",
    "img/sunset.jpeg"
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title><?php echo htmlspecialchars($username); ?> • Werv</title>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/index_search.css" />
    <link rel="stylesheet" href="css/profile.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
</head>
<body>

<div class="search-sidebar" id="searchSidebar">
    <div class="search-header">
        <input type="text" placeholder="Search users..." id="searchInput">
        <i class="fa-solid fa-xmark close-search" onclick="toggleSearchSidebar()"></i>
    </div>
    <div class="search-results" id="searchResults"></div>
</div>

<div class="container">
    <header>
        <div class="logo"><h1>Werv</h1></div>
    </header>

    <div class="pages">
        <div class="icon"><i class="fa-solid fa-house"></i><a href="index.php">Home</a></div>
        <div class="icon"><i class="fa-regular fa-paper-plane"></i><a href="messages.php">Messages</a></div>
        <div class="icon"><i class="fa-regular fa-comments"></i><a href="chat.php">Open Chat</a></div>
        <div class="icon" id="searchButton"><i class="fa fa-search"></i><p>Search</p></div>
        <div class="icon"><i class="fa-regular fa-bell"></i><p>Notification</p></div>
        <div class="icon"><i class="fa-regular fa-plus"></i><a href="add_post.php">Add Post</a></div>
        <div class="icon pdp_image">
            <?php if (!empty($profile_pic) && file_exists("uploads/" . $profile_pic)): ?>
                <img src="uploads/<?php echo htmlspecialchars($profile_pic); ?>" alt="Profile" />
            <?php else: ?>
                <img src="img/default.png" alt="Default Profile" />
            <?php endif; ?>
            <p><?php echo htmlspecialchars($username); ?></p>
        </div>
    </div>

    <div class="bars" onclick="window.location.href='logout.php'">
        <i class="fa-solid fa-right-from-bracket"></i>
        <p>Logout</p>
    </div>
</div>

<div class="profile-container">
    <div class="profile-top">
        <div class="profile-image">
            <img src="<?php echo !empty($profile_pic) && file_exists("uploads/$profile_pic") ? "uploads/$profile_pic" : 'img/profile.png'; ?>" alt="Profile Picture" />
        </div>
        <div class="profile-info">
            <div class="profile-header">
                <h2><?php echo htmlspecialchars($username); ?></h2>

                <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != $profile_id): ?>
                    <button class="follow-btn" id="followBtn" 
                        data-following="<?= $is_following ? '1' : '0' ?>" 
                        data-followed-id="<?= $profile_id ?>">
                        <?= $is_following ? 'Unfollow' : 'Follow' ?>
                    </button>
                    <button class="message-btn">Message</button>
                <?php endif; ?>

                <i class="fa-solid fa-ellipsis options-btn"></i>
            </div>
            <div class="profile-stats">
                <span><strong><?php echo count($posts); ?></strong> posts</span>
                <span><strong><?php echo $followers_count; ?></strong> followers</span>
                <span><strong><?php echo $following_count; ?></strong> following</span>
            </div>
            <div class="profile-name">
                <strong><?php echo htmlspecialchars($fullname); ?></strong>
            </div>
        </div>
    </div>

    <div class="profile-posts">
        <?php foreach ($posts as $img): ?>
            <div class="grid-post">
                <img src="<?php echo htmlspecialchars($img); ?>" alt="Post Image" />
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Scripts -->
<script src="js/follow.js"></script>
<script src="js/searchslid.js"></script>
<script src="js/profile.js"></script>

</body>
</html>
