<?php
session_start();
require_once "db.php";
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/dm.css">
    <title>Wern - Your inbox</title>
</head>
<body>
    <div class="container">
    <div class="pages">
        <div class="icon"><i class="fa-solid fa-house"></i></div>
        <div class="icon"><i class="fa-regular fa-paper-plane"></i></div>
        <div class="icon"><i class="fa-regular fa-comments"></i></div>
        <div class="icon" id="searchButton"><i class="fa fa-search"></i></div>
        <div class="icon"><i class="fa-regular fa-bell"></i></div>
        <div class="icon"><i class="fa-regular fa-plus"></i></div>
        <div class="icon pdp_image">
            <?php if (!empty($profilePic) && file_exists("uploads/" . $profilePic)): ?>
                <img src="uploads/<?php echo htmlspecialchars($profilePic); ?>" alt="Profile">
            <?php else: ?>
                <img src="img/default.png" alt="Default Profile">
            <?php endif; ?>
        </div>
    </div>
    </div>
</body>
</html>