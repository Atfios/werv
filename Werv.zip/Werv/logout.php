<?php
session_start();

require_once "db.php";

// تحقق من الاتصال
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// التحقق واش كاين كوكي ديال التوكن
if (isset($_COOKIE['remember_token'])) {
    $token = $_COOKIE['remember_token'];

    // حذف التوكن من جدول users
    $stmt = $conn->prepare("UPDATE users SET remember_token = NULL WHERE remember_token = ?");
    if ($stmt) {
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $stmt->close();
    }

    // حذف الكوكي من المتصفح
    setcookie('remember_token', '', time() - 3600, "/");
}

// حذف بيانات السيشن
$_SESSION = [];
session_destroy();

// غلق الاتصال
$conn->close();

// توجيه المستخدم لصفحة تسجيل الدخول
header("Location: login.php");
exit;
?>
