<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['user_id']) || !isset($_POST['followed_id'], $_POST['action'])) {
    echo "error";
    exit();
}

$follower_id = $_SESSION['user_id'];
$followed_id = intval($_POST['followed_id']);
$action = $_POST['action'];

if ($follower_id == $followed_id) {
    echo "error";
    exit();
}

if ($action == 'follow') {
    $stmt = $conn->prepare("INSERT IGNORE INTO follows (follower_id, followed_id, created_at) VALUES (?, ?, NOW())");
    $stmt->bind_param("ii", $follower_id, $followed_id);
    $stmt->execute();
    $stmt->close();
    echo "success";
} elseif ($action == 'unfollow') {
    $stmt = $conn->prepare("DELETE FROM follows WHERE follower_id = ? AND followed_id = ?");
    $stmt->bind_param("ii", $follower_id, $followed_id);
    $stmt->execute();
    $stmt->close();
    echo "success";
} else {
    echo "error";
}
?>
